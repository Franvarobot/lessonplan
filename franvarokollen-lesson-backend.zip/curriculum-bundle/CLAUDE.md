# CLAUDE.md — Lesson Plan Generator integration guide

> **Read this file first** before making changes to anything in `/curriculum` or `/generator`. It explains what this module is, what it isn't, and how it's meant to be wired into the Frånvarokollen backend.

## What this module is

A **standalone TypeScript module** that generates Swedish-curriculum-aligned lesson plans for substitute teachers (vikarier). It was prototyped separately to validate the design before integration with Frånvarokollen.

The module has two layers:

```
curriculum/    Skolverket curriculum data + lookup logic (deterministic, no LLM)
generator/     Prompt builder + LLM orchestrator (calls Claude API)
```

The companion mockup at `https://franvarobot.github.io/lessonplan/` shows the intended UX. The mockup uses a stub generator for offline demo; this module is the real thing.

## High-level flow

```
User clicks "Skapa lektion" on a Daily Cover row
    ↓
Frånvarokollen backend receives request: { lessonId }
    ↓
Backend resolves lessonId → { subject, grade, durationMinutes, language }
    ↓
generator/generate.ts → generateLessonPlan(request, { backend })
    ↓
    ├─ curriculum/lookup.ts → finds matching centralt innehåll + betygskriterier
    ├─ generator/prompt.ts  → builds bilingual prompt with curriculum injected
    └─ LLMBackend.call()    → Anthropic API (or proxy) → JSON response
    ↓
Backend persists plan, returns to frontend
    ↓
Frontend renders with the same PlanView component used in the mockup
```

## Critical: curriculum data is DRAFT

**Both `lgr22.json` and `gy11.json` carry a `verification_status: "draft"` field.**

The data was authored from training data, not scraped from Skolverket. What's accurate:
- Subject codes (e.g. `MATMAT01b`, `SVESVE01`) — real
- Grade spans (1-3, 4-6, 7-9), E/C/A scale, category names — real
- General content/topics covered at each level — directionally correct

What's not verified:
- Exact wording of *centralt innehåll* bullets may differ from Skolverket's official text
- *Betygskriterier* summaries are paraphrased, not quoted

**Do NOT ship this to production without a verification pass.** Three options, in order of preference:

1. **Skolverket API integration** — `https://api.skolverket.se/syllabus/v1/` exposes current syllabi. Write a build-time script that regenerates the JSON from the API. Then the disclaimer comes off.
2. **Manual review** — a Swedish teacher cross-checks each bullet against Skolverket's official PDFs. A few hours of work for the current coverage.
3. **Live scrape** — fetch Skolverket's website, parse, rebuild JSON. Yearly job.

Until one of these is done, surface the disclaimer in any UI that shows the curriculum bullets to teachers, or only render the higher-level summary.

## File-by-file

### `curriculum/lgr22.json`
Lgr22 grundskola data: 8 subjects (svenska, matematik, engelska, NO, SO, idrott, bild, musik) × 3 grade spans (1-3, 4-6, 7-9). Each entry has *centralt innehåll* (categorized) and a *betygskriterier_summary*. Top-level fields: `schema_version`, `source`, `verification_status`, `official_sources`, `stage`, `subjects`.

### `curriculum/gy11.json`
Gy11 gymnasium courses: 12 core courses (Svenska 1/2, Matematik 1a/1b/1c, Engelska 5/6, Historia 1a1, Naturkunskap 1a1, Samhällskunskap 1a1, Religionskunskap 1, Idrott och hälsa 1). Each entry has `subject_code`, `name_sv`, `credits`, `level`, optional `track`, `centralt_innehall` (flat array), and `kunskapskrav_summary`.

### `curriculum/lookup.ts`
Public API for resolving subject + grade → curriculum match. Three exported functions:
- `lookupCurriculum(opts)` — main entry; takes `{ stage, subject, grade?, track? }`, returns `CurriculumMatch | null`. Handles aliases ("biologi" → NO, "matte" → matematik, "sve" → svenska) and grade-to-span rollup (grade 5 → "4-6").
- `listSubjects(stage)` — for UI dropdowns.
- `buildCurriculumContext(match)` — produces the LLM-ready text block injected into prompts.

If you extend the JSON, also extend the alias maps in `lookup.ts` (`GRUNDSKOLA_ALIASES`, `GYMNASIUM_SUBJECT_TO_COURSES`).

### `generator/types.ts`
Type definitions for `LessonPlanRequest` and `LessonPlan`. Read these first — everything else is shaped by them. Key types:
- `LessonPlanRequest` — input shape; supports both `mode: 'quick'` (one-click on absence row) and `mode: 'studio'` (full options page).
- `LessonPlan` — output shape; phases, exit exercise, optional add-ons (extra activities, differentiation), vikarie notes.

### `generator/prompt.ts`
Bilingual prompt builder. `buildPrompt(request, curriculum)` returns `{ system, user }`. The system prompt enforces JSON-only output and curriculum alignment. The user prompt is constructed in 6 sections: parameters, optional studio fields, curriculum context, add-on instructions, response schema, language reminder.

When you add a new add-on or input field, update both `types.ts` AND `prompt.ts`. Don't forget the SV/EN parallel strings.

### `generator/generate.ts`
The orchestrator. Exports:
- `generateLessonPlan(request, options)` — main entry point.
- `createAnthropicBackend(opts)` — production backend. Reads `ANTHROPIC_API_KEY` from env or accepts it as `opts.apiKey`. Default model: `claude-sonnet-4-5-20250929`. Edit this when newer models are appropriate.
- `createStubBackend()` — offline canned responses for tests/demos.
- `LLMBackend` interface — implement this to route through your own proxy instead of calling Anthropic directly.

JSON parsing is defensive (strips `\`\`\`json` fences, extracts first `{...}` block). If the model misbehaves, errors include the first 500 chars of the bad output.

## How to integrate into Frånvarokollen

### Step 1 — copy the module in
Drop `/curriculum` and `/generator` into the backend repo. The TypeScript is dependency-free except for Node's built-in `fetch` (Node 18+).

### Step 2 — wire an HTTP endpoint
Something like:

```ts
// POST /api/lessons/generate
import { generateLessonPlan, createAnthropicBackend } from './generator/generate';

const backend = createAnthropicBackend({ apiKey: process.env.ANTHROPIC_API_KEY });

app.post('/api/lessons/generate', async (req, res) => {
  // 1. Look up the absence/lesson row to get subject, grade, duration
  const lesson = await db.lessons.findById(req.body.lessonId);
  if (!lesson) return res.status(404).end();

  // 2. Build the request
  const request: LessonPlanRequest = {
    mode: req.body.mode ?? 'quick',
    language: req.body.language ?? 'sv',
    stage: lesson.stage,            // 'grundskola' | 'gymnasium'
    subject: lesson.subjectKey,     // e.g. 'matematik' or 'MATMAT01b'
    grade: lesson.grade,
    durationMinutes: lesson.durationMinutes,
    // Studio-only fields if mode === 'studio':
    learningGoal: req.body.learningGoal,
    materialsAvailable: req.body.materialsAvailable,
    addOns: req.body.addOns,
    // ...
  };

  // 3. Generate
  try {
    const result = await generateLessonPlan(request, { backend });
    // 4. Persist
    await db.lessonPlans.insert({
      lessonId: lesson.id,
      plan: result.plan,
      meta: result.meta,
      createdAt: new Date(),
    });
    res.json(result);
  } catch (e) {
    console.error('Lesson generation failed:', e);
    res.status(500).json({ error: 'generation_failed' });
  }
});
```

### Step 3 — frontend integration
The mockup shows the intended UI: button on each Daily Cover row → modal with PlanView. Port the React components from `index.html` (in the `franvarobot/lessonplan` repo) into your Frånvarokollen frontend. The PlanView component is the shared piece that renders in three contexts: modal, full-page, mobile sub view.

### Step 4 — substitute delivery
Once the plan is saved, three delivery surfaces:
1. **Modal** in coordinator UI (already in mockup)
2. **Printable full page** at `/lessons/:id/plan` (mockup shows the design)
3. **Mobile sub view** at a signed-token URL like `/v/:token` — the vikarie taps this from SMS/email and sees a read-only mobile-optimized view. Sign the token with a short TTL (e.g. 24h after the lesson) and the lessonId payload.

### Step 5 — costs / rate limiting
Each generation is roughly:
- ~2-4k input tokens (system prompt + curriculum context + parameters)
- ~1-2k output tokens (full lesson plan JSON)

Cache plans by `(lessonId, request hash)` so re-generations don't burn credits unless the user explicitly clicks "Regenerate".

## Things to watch out for

- **Don't run the LLM call from the frontend.** Always proxy through the backend so the API key stays server-side.
- **Validate parsed JSON before persisting.** The model occasionally drops fields. Defaults are filled in `generate.ts` but worth a Zod/Valibot schema before insert.
- **Keep the `curriculum/` JSON pure data.** No code in the JSON, no interpolation. The lookup logic stays in `lookup.ts`.
- **Re-run the curriculum verification yearly.** Lgr22 has had revisions; Gy25 is rolling out. Bake this into a recurring task.
- **Translate when curriculum data is in Swedish but user wants English.** The `prompt.ts` already handles this — Swedish curriculum gets injected, the LLM is instructed to translate output to the requested language. Don't translate the JSON source data itself; let the model do it at generation time.

## Testing

Run the smoke tests:

```bash
cd curriculum && npx tsx test.ts   # 9 tests, lookup-only, no LLM
cd generator && npx tsx test.ts    # 5 tests, end-to-end with stub backend
```

For real LLM testing:

```bash
ANTHROPIC_API_KEY=sk-ant-... npx tsx <<< '
import { generateLessonPlan, createAnthropicBackend } from "./generator/generate";
const backend = createAnthropicBackend();
const result = await generateLessonPlan(
  { mode: "quick", language: "sv", stage: "grundskola", subject: "matematik", grade: 5, durationMinutes: 60 },
  { backend }
);
console.log(JSON.stringify(result.plan, null, 2));
'
```

## Open questions for the integrator

1. Where should saved plans live in the schema — `lesson_plans` table linked by `lesson_id`, or as a JSON column on the existing `lessons` table?
2. How should regeneration be tracked? Versioning? Last-write-wins?
3. Who owns the substitute-link signing — this module, or your existing auth layer?
4. Is there a per-school override needed? (e.g. a school adds local context to every prompt)
5. What's the fallback if the LLM call fails? Show a "try again" button, or queue + retry?

If unsure, ask the project owner (Baz / @Franvarobot) before making structural decisions. The mockup at `https://franvarobot.github.io/lessonplan/` is the source of truth for the intended UX.
