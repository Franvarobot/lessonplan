# Lesson Plan Generator — backend module

The TypeScript module behind the [lesson plan generator mockup](https://franvarobot.github.io/lessonplan/). This is what gets wired into the Frånvarokollen backend when we move from prototype to production.

> **For Claude / LLMs: read [`CLAUDE.md`](./CLAUDE.md) before making changes.**

## What's in here

```
curriculum/
  lgr22.json     Lgr22 grundskola data (8 subjects × 3 grade spans)
  gy11.json      Gy11 gymnasium courses (12 core courses)
  lookup.ts      Subject/grade → curriculum content
  test.ts        Lookup smoke tests

generator/
  types.ts       Request/response type definitions
  prompt.ts      Bilingual prompt builder (sv/en)
  generate.ts    LLM orchestrator + pluggable backend interface
  test.ts        End-to-end smoke tests (uses stub backend)

CLAUDE.md        Integration playbook
README.md        This file
tsconfig.json    Minimal TS config
```

## ⚠️ Curriculum data is DRAFT

Both JSON files carry a `verification_status: "draft"` field. The data was authored from training data and is **directionally correct but not byte-for-byte accurate** to Skolverket's official text. Verify against `https://api.skolverket.se/syllabus/v1/` before production. See `CLAUDE.md` for the full disclaimer and remediation options.

## Quick test

```bash
# Lookup only (no LLM, no API key)
cd curriculum && npx tsx test.ts

# End-to-end with stub backend (exercises curriculum lookup, prompt building,
# JSON parsing, and the new extraTime tier output)
cd generator && npx tsx test.ts
```

Both should show all green checkmarks. The generator test prints the four extra-time tiers for each generated plan so you can see they made it through end to end.

## What the LessonPlan looks like

Every generated plan has these sections (some optional):

- **title, summary, learningGoal** — header info
- **curriculumLinks** — Skolverket centralt innehåll + betygskriterier excerpt
- **materialsNeeded** — what the substitute needs at hand
- **phases** — the lesson flow with timing and concrete teacher/student actions
- **exitExercise** *(optional)* — short closing activity
- **extraActivities** *(optional)* — for individual fast finishers
- **differentiation** *(optional)* — `{ stod, utmaning }` for support and challenge
- **extraTime** *(optional, default-on in quick mode)* — exactly 4 tiers (5/10/15/20 min) of class-wide extensions when the substitute finishes early. Each carries a `linkBack` field explaining how it builds on what the lesson actually covered.
- **vikarieNotes** — practical tips the substitute reads before stepping in

## Real LLM call

```ts
import { generateLessonPlan, createAnthropicBackend } from './generator/generate';

const backend = createAnthropicBackend({ apiKey: process.env.ANTHROPIC_API_KEY });

const result = await generateLessonPlan({
  mode: 'quick',
  language: 'sv',
  stage: 'grundskola',
  subject: 'matematik',
  grade: 5,
  durationMinutes: 60,
}, { backend });

console.log(result.plan);
```

## Companion mockup

Live demo of the intended UX (uses a stub generator, runs entirely in-browser):

→ **https://franvarobot.github.io/lessonplan/**

The mockup repo is at `Franvarobot/lessonplan`. This module is the production backend that should eventually replace the stub.

## License & ownership

Internal Frånvarokollen project. Contact Baz (@Franvarobot) before redistributing.
