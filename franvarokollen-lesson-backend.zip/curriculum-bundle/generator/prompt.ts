/**
 * Prompt builder for the lesson plan generator.
 *
 * Takes a LessonPlanRequest plus curriculum context, returns the system
 * prompt + user prompt that get sent to the LLM.
 */

import type { LessonPlanRequest } from './types';
import type { CurriculumMatch } from '../curriculum/lookup';
import { buildCurriculumContext } from '../curriculum/lookup';

export interface BuiltPrompt {
  system: string;
  user: string;
}

const SYSTEM_PROMPT_SV = `Du är en erfaren svensk pedagog som skapar lektionsplaneringar åt vikarier.

Din uppgift: skriv en konkret, genomförbar lektionsplanering som en vikarie kan använda direkt utan förberedelse. Vikarien kanske inte är ämneslärare i ämnet — gör planeringen självgående.

Krav:
- Följ svenska läroplanen (Lgr22 för grundskola, Gy11/Gy25 för gymnasium)
- Använd det centrala innehåll och de betygskriterier som anges nedan
- Konkreta tider, konkreta aktiviteter, konkreta instruktioner
- Inga vaga formuleringar som "diskutera ämnet" — skriv exakt vad läraren säger eller frågar
- Material som krävs ska vara realistiskt för ett vanligt klassrum
- Anpassa språk och svårighetsgrad till årskursen

Svara ENDAST med giltig JSON enligt det schema som anges. Ingen text före eller efter JSON-objektet.`;

const SYSTEM_PROMPT_EN = `You are an experienced Swedish educator creating lesson plans for substitute teachers.

Your task: write a concrete, executable lesson plan a substitute can use immediately without preparation. The substitute may not be a subject specialist — make the plan self-sufficient.

Requirements:
- Follow the Swedish curriculum (Lgr22 for compulsory school, Gy11/Gy25 for upper secondary)
- Use the central content and grading criteria provided below
- Concrete timing, concrete activities, concrete instructions
- No vague phrases like "discuss the topic" — write exactly what the teacher says or asks
- Materials must be realistic for a normal classroom
- Match language and difficulty to the grade level

Reply with valid JSON only, matching the schema provided. No text before or after the JSON object.`;

const RESPONSE_SCHEMA = `{
  "title": string,
  "summary": string (1-2 sentences),
  "learningGoal": string (written for students, "I can..." style),
  "curriculumLinks": {
    "centralInnehall": string[] (2-4 bullets directly quoted or closely paraphrased from the provided centralt innehåll),
    "kriterier": string (plain-language version of the criteria this lesson touches)
  },
  "materialsNeeded": string[],
  "phases": [
    {
      "title": string,
      "durationMinutes": number,
      "description": string,
      "teacherActions": string[] (concrete, scripted),
      "studentActions": string[]
    }
  ],
  "exitExercise"?: { "title": string, "durationMinutes": number, "description": string },
  "extraActivities"?: [{ "title": string, "description": string }],
  "differentiation"?: { "stod": string[], "utmaning": string[] },
  "vikarieNotes": string[] (practical tips: classroom management, common pitfalls, how to know it's going well)
}`;

export function buildPrompt(
  request: LessonPlanRequest,
  curriculum: CurriculumMatch,
): BuiltPrompt {
  const isSv = request.language === 'sv';
  const system = isSv ? SYSTEM_PROMPT_SV : SYSTEM_PROMPT_EN;

  const curriculumContext = buildCurriculumContext(curriculum);

  const duration = request.durationMinutes ?? 60;
  const addOns = resolveAddOns(request);

  const userParts: string[] = [];

  // ---- Section 1: lesson parameters ----
  if (isSv) {
    userParts.push('## Lektionsparametrar');
    userParts.push(`- Stadium: ${curriculum.stage}`);
    userParts.push(`- Ämne: ${curriculum.name_sv}`);
    if (curriculum.grade_span) userParts.push(`- Årskurs: ${curriculum.grade_span}`);
    if (curriculum.stage === 'gymnasium') userParts.push(`- Kurskod: ${curriculum.identifier}`);
    userParts.push(`- Lektionslängd: ${duration} minuter`);
    if (request.groupSize) userParts.push(`- Gruppstorlek: ca ${request.groupSize} elever`);
    if (request.tone) userParts.push(`- Önskad ton: ${request.tone}`);
  } else {
    userParts.push('## Lesson parameters');
    userParts.push(`- Stage: ${curriculum.stage}`);
    userParts.push(`- Subject: ${curriculum.name_sv}${curriculum.name_en ? ` (${curriculum.name_en})` : ''}`);
    if (curriculum.grade_span) userParts.push(`- Grade span: ${curriculum.grade_span}`);
    if (curriculum.stage === 'gymnasium') userParts.push(`- Course code: ${curriculum.identifier}`);
    userParts.push(`- Duration: ${duration} minutes`);
    if (request.groupSize) userParts.push(`- Group size: approx. ${request.groupSize} students`);
    if (request.tone) userParts.push(`- Tone: ${request.tone}`);
  }

  // ---- Section 2: optional studio fields ----
  if (request.learningGoal) {
    userParts.push('');
    userParts.push(isSv ? `## Önskat lärandemål\n${request.learningGoal}` : `## Desired learning goal\n${request.learningGoal}`);
  }
  if (request.materialsAvailable && request.materialsAvailable.length > 0) {
    userParts.push('');
    userParts.push(isSv ? '## Material som finns tillgängligt' : '## Materials available');
    request.materialsAvailable.forEach((m) => userParts.push(`- ${m}`));
  }
  if (request.specialNotes) {
    userParts.push('');
    userParts.push(isSv ? `## Särskilda anmärkningar\n${request.specialNotes}` : `## Special notes\n${request.specialNotes}`);
  }

  // ---- Section 3: curriculum context ----
  userParts.push('');
  userParts.push(isSv ? '## Läroplanskontext (Skolverket)' : '## Curriculum context (Skolverket)');
  userParts.push(curriculumContext);

  // ---- Section 4: add-on instructions ----
  userParts.push('');
  userParts.push(isSv ? '## Vad som ska genereras' : '## What to generate');
  userParts.push(isSv ? '- Huvudlektionsplan med faser' : '- Main lesson plan with phases');
  if (addOns.exitExercise) {
    userParts.push(isSv ? '- Avslutningsövning (kort, rolig, knyter ihop lektionen)' : '- Exit exercise (short, fun, ties the lesson together)');
  }
  if (addOns.extraActivities) {
    userParts.push(isSv ? '- 2-3 extra aktiviteter för elever som blir klara tidigt' : '- 2-3 extra activities for early finishers');
  }
  if (addOns.differentiation) {
    userParts.push(isSv ? '- Differentiering: stöd för elever som behöver extra hjälp och utmaning för dem som vill mer' : '- Differentiation: support for students needing scaffolding, challenge for those wanting more');
  }

  // ---- Section 5: schema ----
  userParts.push('');
  userParts.push(isSv ? '## Svarsformat (endast JSON, inget annat)' : '## Response format (JSON only, nothing else)');
  userParts.push(RESPONSE_SCHEMA);

  // ---- Section 6: language reminder ----
  userParts.push('');
  userParts.push(
    isSv
      ? 'VIKTIGT: Skriv allt innehåll i JSON-objektet på svenska.'
      : 'IMPORTANT: Write all content inside the JSON object in English.',
  );

  return { system, user: userParts.join('\n') };
}

function resolveAddOns(request: LessonPlanRequest): {
  exitExercise: boolean;
  extraActivities: boolean;
  differentiation: boolean;
} {
  // Quick mode: lesson plan + exit exercise, nothing else.
  if (request.mode === 'quick') {
    return { exitExercise: true, extraActivities: false, differentiation: false };
  }
  // Studio mode: respect what was passed, default everything to false.
  return {
    exitExercise: request.addOns?.exitExercise ?? false,
    extraActivities: request.addOns?.extraActivities ?? false,
    differentiation: request.addOns?.differentiation ?? false,
  };
}
