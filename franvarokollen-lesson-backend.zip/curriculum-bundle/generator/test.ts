/**
 * End-to-end smoke test for the lesson generator.
 * Run with: npx tsx test.ts
 */

import { generateLessonPlan, createStubBackend } from './generate';
import { buildPrompt } from './prompt';
import { lookupCurriculum } from '../curriculum/lookup';
import type { LessonPlanRequest } from './types';

async function main() {
  // ==========================================================
  // TEST 1: Quick mode — math åk 5 in Swedish
  // (This is what happens when the substitution coordinator
  //  clicks "Create Lesson" on a 6B Matematik row.)
  // ==========================================================
  console.log('='.repeat(70));
  console.log('TEST 1: QUICK mode, Matematik åk 5, sv');
  console.log('='.repeat(70));
  const req1: LessonPlanRequest = {
    mode: 'quick',
    language: 'sv',
    stage: 'grundskola',
    subject: 'matematik',
    grade: 5,
    durationMinutes: 60,
  };
  const r1 = await generateLessonPlan(req1, { backend: createStubBackend() });
  printResult(r1);

  // ==========================================================
  // TEST 2: Studio mode — full options, English
  // ==========================================================
  console.log('\n' + '='.repeat(70));
  console.log('TEST 2: STUDIO mode, Matematik åk 5, en, all add-ons');
  console.log('='.repeat(70));
  const req2: LessonPlanRequest = {
    mode: 'studio',
    language: 'en',
    stage: 'grundskola',
    subject: 'matematik',
    grade: 5,
    durationMinutes: 80,
    learningGoal: 'Students understand fractions through everyday examples.',
    materialsAvailable: ['whiteboard', 'paper', 'tablets'],
    groupSize: 24,
    tone: 'energetic',
    addOns: { extraActivities: true, exitExercise: true, differentiation: true },
  };
  const r2 = await generateLessonPlan(req2, { backend: createStubBackend() });
  printResult(r2);

  // ==========================================================
  // TEST 3: Gymnasium course, direct course code
  // ==========================================================
  console.log('\n' + '='.repeat(70));
  console.log('TEST 3: STUDIO mode, MATMAT01b, sv');
  console.log('='.repeat(70));
  const req3: LessonPlanRequest = {
    mode: 'studio',
    language: 'sv',
    stage: 'gymnasium',
    subject: 'MATMAT01b',
    durationMinutes: 90,
    addOns: { exitExercise: true, differentiation: true },
  };
  const r3 = await generateLessonPlan(req3, { backend: createStubBackend() });
  printResult(r3);

  // ==========================================================
  // TEST 4: Inspect the actual prompt being built
  // ==========================================================
  console.log('\n' + '='.repeat(70));
  console.log('TEST 4: Prompt inspection (no LLM call)');
  console.log('='.repeat(70));
  const curriculum = lookupCurriculum({ stage: 'grundskola', subject: 'matematik', grade: 5 })!;
  const prompt = buildPrompt(req1, curriculum);
  console.log('--- SYSTEM PROMPT ---');
  console.log(prompt.system.slice(0, 300) + '...\n');
  console.log('--- USER PROMPT (first 1500 chars) ---');
  console.log(prompt.user.slice(0, 1500) + '\n...');

  // ==========================================================
  // TEST 5: Error handling — unknown subject
  // ==========================================================
  console.log('\n' + '='.repeat(70));
  console.log('TEST 5: Error handling — unknown subject');
  console.log('='.repeat(70));
  try {
    await generateLessonPlan(
      { mode: 'quick', language: 'sv', stage: 'grundskola', subject: 'klingonska', grade: 5 },
      { backend: createStubBackend() },
    );
    console.log('WRONG — should have thrown');
  } catch (e) {
    console.log('Correctly threw:', (e as Error).message);
  }
}

function printResult(r: any) {
  console.log(`Title: ${r.plan.title}`);
  console.log(`Language: ${r.plan.language}`);
  console.log(`Summary: ${r.plan.summary}`);
  console.log(`Goal: ${r.plan.learningGoal}`);
  console.log(`Curriculum source: ${r.plan.curriculumLinks.nameSv} [${r.plan.curriculumLinks.identifier}]`);
  console.log(`Phases: ${r.plan.phases.length}`);
  r.plan.phases.forEach((p: any, i: number) => {
    console.log(`  ${i + 1}. ${p.title} (${p.durationMinutes} min) — ${p.teacherActions.length} actions`);
  });
  if (r.plan.exitExercise) {
    console.log(`Exit: ${r.plan.exitExercise.title} (${r.plan.exitExercise.durationMinutes} min)`);
  }
  if (r.plan.extraActivities) {
    console.log(`Extra activities: ${r.plan.extraActivities.length}`);
  }
  if (r.plan.differentiation) {
    console.log(`Differentiation: ${r.plan.differentiation.stod.length} stöd, ${r.plan.differentiation.utmaning.length} utmaning`);
  }
  console.log(`Vikarie notes: ${r.plan.vikarieNotes.length}`);
  console.log(`Meta: ${r.meta.model}, ${r.meta.latencyMs}ms, stub=${r.meta.stub}`);
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
