/**
 * Type definitions for the lesson plan generator.
 *
 * Two entry points share these types:
 *   - Quick generate (button on absence row): minimal inputs, fast output
 *   - Lesson Plan Studio (dedicated page): full inputs, all add-ons
 */

import type { Stage, Grade, GradeSpan } from '../curriculum/lookup';

export type Language = 'sv' | 'en';

export type GenerationMode = 'quick' | 'studio';

export interface LessonPlanRequest {
  /** "quick" = button click on absence row. "studio" = full page with all options. */
  mode: GenerationMode;

  /** UI language for the generated plan. */
  language: Language;

  /** Curriculum stage. */
  stage: Stage;

  /** Subject hint (alias OK, e.g. "matte", "biologi") or gymnasium course code. */
  subject: string;

  /** Required for grundskola. Either a number 1-9 or a span. */
  grade?: Grade | GradeSpan;

  /** Optional gymnasium track when subject lookup is ambiguous (e.g. "matematik"). */
  track?: 'yrkesprogram' | 'högskoleförberedande' | 'natur' | 'teknik' | 'samhälle' | 'ekonomi';

  /** Lesson length in minutes. Defaults to 60 if omitted. */
  durationMinutes?: number;

  /** Studio-only: explicit learning goal, free text. */
  learningGoal?: string;

  /** Studio-only: what's available in the room. */
  materialsAvailable?: string[];

  /** Studio-only: roughly how many students. */
  groupSize?: number;

  /** Studio-only: any special needs / context the substitute should know. */
  specialNotes?: string;

  /** Studio-only: tone hint ("calm", "energetic", "exam-prep", etc). */
  tone?: string;

  /** Add-ons. Quick mode forces exitExercise=true and extraTime=true and ignores the rest. */
  addOns?: {
    extraActivities?: boolean;   // for early finishers
    exitExercise?: boolean;      // avslutning / fun closer
    differentiation?: boolean;   // stöd + utmaning
    extraTime?: boolean;         // 5/10/15/20 min tiered extensions for end-of-lesson time
  };
}

// ---------- Response shape ----------

export interface LessonPhase {
  title: string;
  durationMinutes: number;
  description: string;
  /** Concrete teacher actions — what the substitute literally says/does. */
  teacherActions: string[];
  /** What students do. */
  studentActions: string[];
}

export interface DifferentiationBlock {
  /** Support for students who need scaffolding. */
  stod: string[];
  /** Challenge for students who finish early or need more depth. */
  utmaning: string[];
}

export interface LessonPlan {
  language: Language;
  title: string;

  /** Quick summary the coordinator can scan in 5 seconds. */
  summary: string;

  /** Concrete learning goal, written for students. */
  learningGoal: string;

  /** Curriculum references pulled from Skolverket. */
  curriculumLinks: {
    stage: Stage;
    identifier: string;          // subject key or course code
    nameSv: string;
    /** Specific bullets from centralt innehåll most relevant to THIS lesson. */
    centralInnehall: string[];
    /** Plain-language version of the betygskriterier this lesson touches. */
    kriterier: string;
  };

  materialsNeeded: string[];

  /** Lesson flow: typically 3-4 phases (intro / main / summary). */
  phases: LessonPhase[];

  /** Always present in quick mode, optional in studio. */
  exitExercise?: {
    title: string;
    durationMinutes: number;
    description: string;
  };

  /** Studio add-on. */
  extraActivities?: Array<{
    title: string;
    description: string;
  }>;

  /** Studio add-on. */
  differentiation?: DifferentiationBlock;

  /**
   * Extra-time activities for when the substitute finishes early.
   * Always 4 tiers: 5, 10, 15, 20 minutes. Each one references what
   * was actually covered in the main lesson, so the substitute can run
   * a coherent extension rather than random filler.
   */
  extraTime?: ExtraTimeTier[];

  /** Notes for the substitute teacher (vikarie). */
  vikarieNotes: string[];
}

export interface ExtraTimeTier {
  minutes: 5 | 10 | 15 | 20;
  title: string;
  description: string;
  /** One-line explanation of how this builds on what the lesson just covered. */
  linkBack: string;
}

export interface GenerationResult {
  plan: LessonPlan;
  /** For debugging / iteration. */
  meta: {
    model: string;
    promptTokens?: number;
    completionTokens?: number;
    latencyMs: number;
    stub: boolean;
  };
}
