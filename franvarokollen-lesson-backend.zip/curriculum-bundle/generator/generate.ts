/**
 * Lesson plan generator.
 *
 * Orchestrates: curriculum lookup -> prompt building -> LLM call -> typed response.
 *
 * Two backends:
 *   - "anthropic": real Anthropic API call (needs ANTHROPIC_API_KEY)
 *   - "stub": returns a canned response so the UI can be developed/tested offline
 *
 * Designed so a backend proxy can be slotted in later by implementing the LLMBackend interface.
 */

import { lookupCurriculum, type CurriculumMatch } from '../curriculum/lookup';
import { buildPrompt } from './prompt';
import type {
  GenerationResult,
  LessonPlan,
  LessonPlanRequest,
} from './types';

// ---------- Backend interface ----------

export interface LLMBackend {
  name: string;
  /** Returns the raw model output (expected to be JSON text). */
  call(system: string, user: string): Promise<{
    text: string;
    model: string;
    promptTokens?: number;
    completionTokens?: number;
  }>;
}

// ---------- Anthropic backend ----------

export interface AnthropicBackendOptions {
  apiKey?: string;
  model?: string;
  maxTokens?: number;
}

export function createAnthropicBackend(opts: AnthropicBackendOptions = {}): LLMBackend {
  const apiKey = opts.apiKey ?? process.env.ANTHROPIC_API_KEY;
  const model = opts.model ?? 'claude-sonnet-4-5-20250929';
  const maxTokens = opts.maxTokens ?? 4096;

  return {
    name: `anthropic:${model}`,
    async call(system, user) {
      if (!apiKey) {
        throw new Error('ANTHROPIC_API_KEY not set. Pass apiKey explicitly or set the env var.');
      }
      const res = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': apiKey,
          'anthropic-version': '2023-06-01',
        },
        body: JSON.stringify({
          model,
          max_tokens: maxTokens,
          system,
          messages: [{ role: 'user', content: user }],
        }),
      });
      if (!res.ok) {
        const errBody = await res.text();
        throw new Error(`Anthropic API ${res.status}: ${errBody}`);
      }
      const data = await res.json();
      const text = (data.content || [])
        .filter((b: any) => b.type === 'text')
        .map((b: any) => b.text)
        .join('');
      return {
        text,
        model,
        promptTokens: data.usage?.input_tokens,
        completionTokens: data.usage?.output_tokens,
      };
    },
  };
}

// ---------- Stub backend (offline / mockup mode) ----------

export function createStubBackend(): LLMBackend {
  return {
    name: 'stub',
    async call(_system, user) {
      // Detect language from the prompt content (rough but works for the mockup).
      const isSv = /Lektionsparametrar/.test(user) || /Skriv allt innehåll/.test(user);
      const isMath = /Matematik/.test(user) || /Mathematics/.test(user);

      const plan = isSv ? stubPlanSv(isMath) : stubPlanEn(isMath);
      return {
        text: JSON.stringify(plan),
        model: 'stub-canned-response',
      };
    },
  };
}

// ---------- Main entry point ----------

export interface GenerateOptions {
  backend?: LLMBackend;
}

export async function generateLessonPlan(
  request: LessonPlanRequest,
  options: GenerateOptions = {},
): Promise<GenerationResult> {
  const start = Date.now();

  // 1. Curriculum lookup
  const curriculum = lookupCurriculum({
    stage: request.stage,
    subject: request.subject,
    grade: request.grade,
    track: request.track,
  });
  if (!curriculum) {
    throw new Error(
      `No curriculum match for stage="${request.stage}", subject="${request.subject}", grade="${request.grade}"`,
    );
  }

  // 2. Prompt building
  const { system, user } = buildPrompt(request, curriculum);

  // 3. LLM call
  const backend = options.backend ?? createStubBackend();
  const raw = await backend.call(system, user);

  // 4. Parse JSON (defensive — strip markdown fences if model added them)
  const parsed = parseLLMJson(raw.text);

  // 5. Stitch the curriculum metadata onto the response
  const plan: LessonPlan = {
    language: request.language,
    title: parsed.title,
    summary: parsed.summary,
    learningGoal: parsed.learningGoal,
    curriculumLinks: {
      stage: curriculum.stage,
      identifier: curriculum.identifier,
      nameSv: curriculum.name_sv,
      centralInnehall: parsed.curriculumLinks?.centralInnehall ?? [],
      kriterier: parsed.curriculumLinks?.kriterier ?? '',
    },
    materialsNeeded: parsed.materialsNeeded ?? [],
    phases: parsed.phases ?? [],
    exitExercise: parsed.exitExercise,
    extraActivities: parsed.extraActivities,
    differentiation: parsed.differentiation,
    vikarieNotes: parsed.vikarieNotes ?? [],
  };

  return {
    plan,
    meta: {
      model: raw.model,
      promptTokens: raw.promptTokens,
      completionTokens: raw.completionTokens,
      latencyMs: Date.now() - start,
      stub: backend.name === 'stub',
    },
  };
}

// ---------- Helpers ----------

function parseLLMJson(text: string): any {
  let cleaned = text.trim();
  // Strip ```json ... ``` fences if present
  cleaned = cleaned.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/i, '');
  // If the model wrapped JSON in prose, try to extract the first { ... } block
  const firstBrace = cleaned.indexOf('{');
  const lastBrace = cleaned.lastIndexOf('}');
  if (firstBrace > 0 && lastBrace > firstBrace) {
    cleaned = cleaned.slice(firstBrace, lastBrace + 1);
  }
  try {
    return JSON.parse(cleaned);
  } catch (e) {
    throw new Error(`Failed to parse LLM JSON output: ${(e as Error).message}\n---\n${text.slice(0, 500)}`);
  }
}

// ---------- Canned stub responses ----------

function stubPlanSv(isMath: boolean): any {
  if (isMath) {
    return {
      title: 'Bråk i vardagen',
      summary: 'En 60-minuters lektion där eleverna utforskar bråk genom konkreta vardagsexempel och en kort avslutande quiz.',
      learningGoal: 'Jag kan förklara vad ett bråk är och visa exempel på bråk i min vardag.',
      curriculumLinks: {
        centralInnehall: [
          'Tal i bråk- och decimalform och deras användning i vardagliga situationer.',
          'Strategier för matematisk problemlösning i vardagliga situationer.',
        ],
        kriterier:
          'Eleverna ska kunna identifiera och förklara enkla bråk samt lösa problem som involverar bråk i vardagliga sammanhang.',
      },
      materialsNeeded: ['Whiteboard och pennor', 'Papper till varje elev', 'Färgade pennor (om möjligt)'],
      phases: [
        {
          title: 'Introduktion',
          durationMinutes: 10,
          description: 'Aktivera elevernas förkunskaper genom att visa vardagsexempel på bråk.',
          teacherActions: [
            'Skriv "1/2" på tavlan och fråga: "Var har ni sett detta?"',
            'Lyssna på 3-4 svar. Skriv upp dem på tavlan.',
            'Säg: "Idag ska vi titta på bråk i vår vardag."',
          ],
          studentActions: ['Räcker upp handen och delar med sig av exempel.', 'Antecknar i sitt block.'],
        },
        {
          title: 'Huvudaktivitet — bråk i vardagen',
          durationMinutes: 30,
          description: 'Eleverna arbetar i par med en uppgiftsfaktor: rita upp 6 vardagsbråk.',
          teacherActions: [
            'Dela ut papper till varje par.',
            'Säg: "Ni ska rita 6 bilder där ni kan se ett bråk. Skriv bråket bredvid bilden."',
            'Gå runt och hjälp par som fastnar. Fråga: "Vad är hela här? Vad är delen?"',
          ],
          studentActions: [
            'Diskuterar med sin partner.',
            'Ritar 6 vardagsbilder med bråk (t.ex. en pizza i 4 delar, ett glas till hälften fullt).',
            'Skriver bråket bredvid varje bild.',
          ],
        },
        {
          title: 'Sammanfattning',
          durationMinutes: 15,
          description: 'Par redovisar 1-2 bilder för klassen och bråk samlas på tavlan.',
          teacherActions: [
            'Be 4-5 par dela en bild var.',
            'Skriv alla bråk på tavlan när de delas.',
            'Fråga klassen: "Vilket bråk är störst? Hur vet vi det?"',
          ],
          studentActions: ['Visar sin bild och förklarar bråket.', 'Jämför olika bråk muntligt.'],
        },
      ],
      exitExercise: {
        title: 'Bråk-biljett ut',
        durationMinutes: 5,
        description:
          'Varje elev skriver på en lapp: ett bråk de såg under lektionen + en plats där de tror de kommer se bråk imorgon. Lämna lappen vid dörren när de går ut.',
      },
      vikarieNotes: [
        'Om eleverna säger "jag har aldrig sett bråk" — ge ett exempel: "Hälften av en macka."',
        'Vanlig fallgrop: elever skriver bara siffror. Insistera på en bild först, bråket kommer naturligt.',
        'Det går bra om diskussionen blir livlig — det betyder att de tänker.',
      ],
    };
  }
  // Generic fallback
  return {
    title: 'Lektion (exempel)',
    summary: 'En generell lektion genererad i stub-läge.',
    learningGoal: 'Jag kan delta aktivt i dagens lektion.',
    curriculumLinks: {
      centralInnehall: ['(stub) Centralt innehåll skulle hämtas från Skolverket här.'],
      kriterier: '(stub) Betygskriterier sammanfattning.',
    },
    materialsNeeded: ['Whiteboard', 'Papper'],
    phases: [
      {
        title: 'Introduktion',
        durationMinutes: 10,
        description: 'Introducera dagens ämne.',
        teacherActions: ['Hälsa klassen välkommen.', 'Förklara dagens mål.'],
        studentActions: ['Lyssna och ställa frågor.'],
      },
      {
        title: 'Huvudaktivitet',
        durationMinutes: 40,
        description: 'Arbete i par eller individuellt.',
        teacherActions: ['Dela ut uppgift.', 'Stötta efter behov.'],
        studentActions: ['Arbeta med uppgiften.'],
      },
      {
        title: 'Avslutning',
        durationMinutes: 10,
        description: 'Sammanfattning av vad som lärts.',
        teacherActions: ['Be elever dela en sak de lärt sig.'],
        studentActions: ['Reflektera och dela.'],
      },
    ],
    exitExercise: {
      title: 'Exit-fråga',
      durationMinutes: 3,
      description: 'En sak du tar med dig från idag.',
    },
    vikarieNotes: ['Detta är ett stub-svar — riktigt innehåll genereras av LLM.'],
  };
}

function stubPlanEn(isMath: boolean): any {
  if (isMath) {
    return {
      title: 'Fractions in everyday life',
      summary: 'A 60-minute lesson where students explore fractions through concrete examples from daily life and a short closing quiz.',
      learningGoal: 'I can explain what a fraction is and give examples of fractions in my everyday life.',
      curriculumLinks: {
        centralInnehall: [
          'Numbers in fraction and decimal form and their use in everyday situations.',
          'Strategies for mathematical problem-solving in everyday situations.',
        ],
        kriterier: 'Students should be able to identify and explain simple fractions, and solve problems involving fractions in everyday contexts.',
      },
      materialsNeeded: ['Whiteboard and markers', 'Paper for each student', 'Colored pencils if possible'],
      phases: [
        {
          title: 'Introduction',
          durationMinutes: 10,
          description: 'Activate prior knowledge by showing everyday fraction examples.',
          teacherActions: [
            'Write "1/2" on the board and ask: "Where have you seen this?"',
            'Listen to 3-4 answers. Write them on the board.',
            'Say: "Today we\'re going to look at fractions in our daily lives."',
          ],
          studentActions: ['Raise hands and share examples.', 'Take notes.'],
        },
        {
          title: 'Main activity — fractions around us',
          durationMinutes: 30,
          description: 'Students work in pairs to draw 6 everyday fractions.',
          teacherActions: [
            'Hand out paper to each pair.',
            'Say: "Draw 6 pictures where you can see a fraction. Write the fraction next to each picture."',
            'Walk around. For stuck pairs ask: "What is the whole here? What is the part?"',
          ],
          studentActions: [
            'Discuss with their partner.',
            'Draw 6 everyday images with fractions (e.g. a pizza in 4 slices, a glass half full).',
            'Write the fraction next to each image.',
          ],
        },
        {
          title: 'Wrap-up',
          durationMinutes: 15,
          description: 'Pairs share 1-2 images with the class and fractions get collected on the board.',
          teacherActions: [
            'Ask 4-5 pairs to share one image each.',
            'Write every fraction on the board as they share.',
            'Ask the class: "Which fraction is biggest? How do we know?"',
          ],
          studentActions: ['Show their image and explain the fraction.', 'Compare different fractions verbally.'],
        },
      ],
      exitExercise: {
        title: 'Fraction exit ticket',
        durationMinutes: 5,
        description: 'Each student writes on a slip: one fraction they saw today + one place they expect to see a fraction tomorrow. Drop the slip at the door on their way out.',
      },
      vikarieNotes: [
        'If a student says "I\'ve never seen a fraction" — give an example: "Half of a sandwich."',
        'Common pitfall: students just write numbers. Insist on a drawing first; the fraction follows naturally.',
        'Lively discussion is a good sign — it means they\'re thinking.',
      ],
    };
  }
  return {
    title: 'Lesson (example)',
    summary: 'A generic lesson generated in stub mode.',
    learningGoal: 'I can participate actively in today\'s lesson.',
    curriculumLinks: {
      centralInnehall: ['(stub) Central content would be loaded from Skolverket here.'],
      kriterier: '(stub) Grading criteria summary.',
    },
    materialsNeeded: ['Whiteboard', 'Paper'],
    phases: [
      {
        title: 'Introduction',
        durationMinutes: 10,
        description: 'Introduce today\'s topic.',
        teacherActions: ['Welcome the class.', 'Explain today\'s goal.'],
        studentActions: ['Listen and ask questions.'],
      },
      {
        title: 'Main activity',
        durationMinutes: 40,
        description: 'Work in pairs or individually.',
        teacherActions: ['Hand out task.', 'Support as needed.'],
        studentActions: ['Work on the task.'],
      },
      {
        title: 'Wrap-up',
        durationMinutes: 10,
        description: 'Summarize what was learned.',
        teacherActions: ['Ask students to share one takeaway.'],
        studentActions: ['Reflect and share.'],
      },
    ],
    exitExercise: {
      title: 'Exit question',
      durationMinutes: 3,
      description: 'One thing you take with you from today.',
    },
    vikarieNotes: ['This is a stub response — real content is generated by the LLM.'],
  };
}
