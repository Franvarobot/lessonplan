/**
 * Smoke test for the curriculum lookup module.
 * Run with: npx tsx test.ts
 */

import { lookupCurriculum, listSubjects, buildCurriculumContext } from './lookup';

console.log('=== TEST 1: Grundskola - Matematik åk 5 ===');
const m1 = lookupCurriculum({ stage: 'grundskola', subject: 'matematik', grade: 5 });
console.log(m1 ? buildCurriculumContext(m1) : 'NOT FOUND');

console.log('\n\n=== TEST 2: Grundskola - Svenska åk 8 (alias "sve") ===');
const m2 = lookupCurriculum({ stage: 'grundskola', subject: 'sve', grade: 8 });
console.log(m2 ? buildCurriculumContext(m2) : 'NOT FOUND');

console.log('\n\n=== TEST 3: Grundskola - Biologi åk 2 (rolls up to NO) ===');
const m3 = lookupCurriculum({ stage: 'grundskola', subject: 'biologi', grade: 2 });
console.log(m3 ? buildCurriculumContext(m3).slice(0, 400) + '...' : 'NOT FOUND');

console.log('\n\n=== TEST 4: Gymnasium - direct course code MATMAT01b ===');
const m4 = lookupCurriculum({ stage: 'gymnasium', subject: 'MATMAT01b' });
console.log(m4 ? buildCurriculumContext(m4) : 'NOT FOUND');

console.log('\n\n=== TEST 5: Gymnasium - subject "matematik" + track "yrkesprogram" ===');
const m5 = lookupCurriculum({ stage: 'gymnasium', subject: 'matematik', track: 'yrkesprogram' });
console.log(`Resolved to: ${m5?.identifier} - ${m5?.name_sv}`);

console.log('\n\n=== TEST 6: Gymnasium - subject "matematik" + track "natur" ===');
const m6 = lookupCurriculum({ stage: 'gymnasium', subject: 'matematik', track: 'natur' });
console.log(`Resolved to: ${m6?.identifier} - ${m6?.name_sv}`);

console.log('\n\n=== TEST 7: Unknown subject ===');
const m7 = lookupCurriculum({ stage: 'grundskola', subject: 'flygteknik', grade: 5 });
console.log(m7 ? 'WRONG' : 'Correctly returned null');

console.log('\n\n=== TEST 8: listSubjects(grundskola) ===');
console.log(listSubjects('grundskola'));

console.log('\n\n=== TEST 9: listSubjects(gymnasium) ===');
console.log(listSubjects('gymnasium'));
