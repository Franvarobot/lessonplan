/**
 * Curriculum lookup module
 * Maps subject + grade/course → centralt innehåll + betygskriterier (Lgr22 / Gy11)
 *
 * Standalone module — no external dependencies.
 * Designed to be consumed by the lesson plan generator (LLM prompt builder).
 */

import lgr22Data from './lgr22.json';
import gy11Data from './gy11.json';

// ---------- Types ----------

export type Stage = 'grundskola' | 'gymnasium';
export type GradeSpan = '1-3' | '4-6' | '7-9';
export type Grade = 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9;
export type GymnasiumYear = 'gy1' | 'gy2' | 'gy3';

export interface CurriculumMatch {
  stage: Stage;
  identifier: string;          // subject key (grundskola) or course code (gymnasium)
  name_sv: string;
  name_en?: string;
  grade_span?: GradeSpan;      // grundskola only
  centralt_innehall: Record<string, string[]> | string[];
  betygskriterier_summary?: string;
  kunskapskrav_summary?: string;
  source: string;
}

export interface LookupOptions {
  stage: Stage;
  /** For grundskola: subject key (e.g. "matematik", "svenska", "no", "so"). For gymnasium: course code (e.g. "MATMAT01b") OR a subject hint. */
  subject: string;
  /** Required for grundskola. Either grade number (1-9) or grade span ("1-3" | "4-6" | "7-9"). */
  grade?: Grade | GradeSpan;
  /** Optional gymnasium track hint when subject is given without explicit course code. */
  track?: 'yrkesprogram' | 'högskoleförberedande' | 'natur' | 'teknik' | 'samhälle' | 'ekonomi';
}

// ---------- Helpers ----------

function gradeToSpan(grade: Grade | GradeSpan): GradeSpan {
  if (typeof grade === 'string') return grade;
  if (grade <= 3) return '1-3';
  if (grade <= 6) return '4-6';
  return '7-9';
}

function normalize(s: string): string {
  return s.toLowerCase().trim().replace(/\s+/g, '');
}

// Common Swedish subject aliases → grundskola JSON keys
const GRUNDSKOLA_ALIASES: Record<string, string> = {
  svenska: 'svenska',
  sve: 'svenska',
  matematik: 'matematik',
  matte: 'matematik',
  ma: 'matematik',
  engelska: 'engelska',
  eng: 'engelska',
  no: 'no',
  biologi: 'no',
  fysik: 'no',
  kemi: 'no',
  naturkunskap: 'no',
  so: 'so',
  geografi: 'so',
  historia: 'so',
  religion: 'so',
  religionskunskap: 'so',
  samhällskunskap: 'so',
  samhallskunskap: 'so',
  samhalle: 'so',
  idrott: 'idrott',
  idrottochhalsa: 'idrott',
  idrottochhälsa: 'idrott',
  bild: 'bild',
  musik: 'musik',
};

// Gymnasium subject hint → list of likely course codes (ordered by commonality)
const GYMNASIUM_SUBJECT_TO_COURSES: Record<string, string[]> = {
  svenska: ['SVESVE01', 'SVESVE02'],
  matematik: ['MATMAT01b', 'MATMAT01a', 'MATMAT01c'],
  matte: ['MATMAT01b', 'MATMAT01a', 'MATMAT01c'],
  engelska: ['ENGENG05', 'ENGENG06'],
  historia: ['HISHIS01a1'],
  naturkunskap: ['NAKNAK01a1'],
  samhällskunskap: ['SAMSAM01a1'],
  samhalle: ['SAMSAM01a1'],
  religion: ['RELRELLAR0'],
  religionskunskap: ['RELRELLAR0'],
  idrott: ['IDRIDR01'],
};

// ---------- Public API ----------

/**
 * Look up curriculum content for a given subject + grade.
 * Returns the matched curriculum entry, or null if no match.
 */
export function lookupCurriculum(opts: LookupOptions): CurriculumMatch | null {
  if (opts.stage === 'grundskola') {
    return lookupGrundskola(opts);
  }
  return lookupGymnasium(opts);
}

function lookupGrundskola(opts: LookupOptions): CurriculumMatch | null {
  if (opts.grade === undefined) return null;

  const span = gradeToSpan(opts.grade);
  const key = GRUNDSKOLA_ALIASES[normalize(opts.subject)];
  if (!key) return null;

  const subj = (lgr22Data as any).subjects[key];
  if (!subj) return null;

  const spanData = subj.grade_spans[span];
  if (!spanData) return null;

  return {
    stage: 'grundskola',
    identifier: key,
    name_sv: subj.name_sv,
    name_en: subj.name_en,
    grade_span: span,
    centralt_innehall: spanData.centralt_innehall,
    betygskriterier_summary: spanData.betygskriterier_summary,
    source: lgr22Data.source,
  };
}

function lookupGymnasium(opts: LookupOptions): CurriculumMatch | null {
  const courses = (gy11Data as any).courses;

  // Direct course code lookup (e.g. "MATMAT01b")
  if (courses[opts.subject]) {
    const c = courses[opts.subject];
    return courseToMatch(opts.subject, c);
  }

  // Subject hint → pick a course based on track
  const candidates = GYMNASIUM_SUBJECT_TO_COURSES[normalize(opts.subject)];
  if (!candidates || candidates.length === 0) return null;

  let chosen = candidates[0];
  if (opts.track) {
    const t = normalize(opts.track);
    const trackMatch = candidates.find((code) => {
      const c = courses[code];
      if (!c?.track) return false;
      const ct = normalize(c.track);
      return ct.includes(t) || t.includes(ct);
    });
    if (trackMatch) chosen = trackMatch;
  }

  return courseToMatch(chosen, courses[chosen]);
}

function courseToMatch(code: string, c: any): CurriculumMatch {
  return {
    stage: 'gymnasium',
    identifier: code,
    name_sv: c.name_sv,
    name_en: c.name_en,
    centralt_innehall: c.centralt_innehall,
    kunskapskrav_summary: c.kunskapskrav_summary,
    source: gy11Data.source,
  };
}

/**
 * List every subject available for a stage (for UI dropdowns).
 */
export function listSubjects(stage: Stage): Array<{ key: string; name_sv: string }> {
  if (stage === 'grundskola') {
    const subjects = (lgr22Data as any).subjects;
    return Object.entries(subjects).map(([key, v]: [string, any]) => ({
      key,
      name_sv: v.name_sv,
    }));
  }
  const courses = (gy11Data as any).courses;
  return Object.entries(courses).map(([code, v]: [string, any]) => ({
    key: code,
    name_sv: v.name_sv,
  }));
}

/**
 * Build a compact curriculum context string suitable for injection into an LLM prompt.
 * This is what the lesson generator will feed Claude alongside the user's lesson request.
 */
export function buildCurriculumContext(match: CurriculumMatch): string {
  const lines: string[] = [];
  lines.push(`Källa: ${match.source}`);
  lines.push(`Ämne: ${match.name_sv}`);
  if (match.grade_span) lines.push(`Årskurs: ${match.grade_span}`);
  if (match.identifier && match.stage === 'gymnasium') {
    lines.push(`Kurskod: ${match.identifier}`);
  }

  lines.push('\n--- Centralt innehåll ---');
  if (Array.isArray(match.centralt_innehall)) {
    match.centralt_innehall.forEach((item) => lines.push(`• ${item}`));
  } else {
    for (const [section, items] of Object.entries(match.centralt_innehall)) {
      lines.push(`\n[${section}]`);
      items.forEach((item) => lines.push(`• ${item}`));
    }
  }

  const criteria = match.betygskriterier_summary ?? match.kunskapskrav_summary;
  if (criteria) {
    lines.push('\n--- Betygskriterier (sammanfattning) ---');
    lines.push(criteria);
  }

  return lines.join('\n');
}
